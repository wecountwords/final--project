from django.contrib.auth.models import AbstractUser
from django.db import models

# Create your models here.

class User(AbstractUser):
    author_first = models.CharField(max_length=50, default="", blank=True)
    author_last = models.CharField(max_length=50, default="", blank=True)
    isContentDeveloper = models.BooleanField(default=False)
    isContentPublisher = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.username} : isContentDev {self.isContentDeveloper}"



class Profile(models.Model):
    member = models.OneToOneField("User", on_delete=models.CASCADE, primary_key=True)
    daily_goal = models.PositiveSmallIntegerField(default=0)
    days_per_week = models.PositiveSmallIntegerField(default=3)

    def __str__(self):
        return f"{self.member}"



class History(models.Model):
    member = models.ForeignKey("User", on_delete=models.CASCADE, related_name="metrics")
    timestamp = models.DateTimeField(auto_now=False, auto_now_add=True)
    words = models.PositiveSmallIntegerField(default=0)

    def __str__(self):
        return self.member
