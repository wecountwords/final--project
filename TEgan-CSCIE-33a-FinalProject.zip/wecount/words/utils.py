import re
from datetime import datetime, date, timedelta
from django.db.models import Sum, Avg, Min, Max
from words.models import History, User
from django.core.exceptions import ObjectDoesNotExist, MultipleObjectsReturned

# error constants
ERROR_INVALID_PARAMETERS = -101
ERROR_INVALID_MEMBER = -201
ERROR_INVALID_QUERY = -301

# global var
cummulative_total_dict = {
    "thisyear": 0,             # this year excluding today's work
    "thismonth": 0,            # this month excluding today's work
    "thisweek": 0,             # this week excluding today's work
    "yesterday": 0,             # total of all words from the pervious day
    "today": 0                  # progressive total of today's words
}

weekday_total_dict = {
    "Sunday": 0,
    "Monday": 0,
    "Tuesday": 0,
    "Wednesday": 0,
    "Thursday": 0,
    "Friday": 0,
    "Saturday": 0
}

# valid interval names: year, month, week, yesteray, today
def get_word_counts(interval, member_id):

    # let's get the current date
    date_now = datetime.now()

    # get the date parameters for each interval option
    if interval == "year":
        d = datetime(date_now.year, 1, 1)

    elif interval == "month":
        d = datetime(date_now.year, date_now.month, 1)

    elif interval == "week":
        d_start = date_now.date() - timedelta(days=int(date_now.strftime("%w")) + 1)
        d_end = date_now.date()

    elif interval == "yesterday":
        d_start = date_now.date() - timedelta(days=1)
        d_end = date_now.date()

    elif interval == "today":
        d = date_now.date()

    else:
        return ERROR_INVALID_PARAMETERS

    member_id = int(member_id)

    # if there is no member id, this is a regional cummulative count
    # calcuate the total words for each interval and exit the function
    if member_id == 0:
        if (interval == "year" or interval == "month"):
            try:
                total = History.objects.exclude(timestamp__lt=d).aggregate(Sum("words"))
            except:
                return ERROR_INVALID_QUERY

        elif (interval == "week" or interval == "yesterday"):
            try:
                total = History.objects.filter(timestamp__gte=d_start, timestamp__lt=d_end).aggregate(Sum("words"))
            except:
                return ERROR_INVALID_QUERY

        elif (interval == "today"):
            try:
                total = History.objects.exclude(timestamp__lt=d).aggregate(Sum("words"))
            except:
                return ERROR_INVALID_QUERY

        # in the total returns none, set the sum to zero
        if total["words__sum"] == None:
            total["words__sum"] = 0

        # return the total word count
        return total["words__sum"]

    # if there is a member id, this is a member-specific request.  get the
    # word count totals for the member
    if member_id > 0:
        # get the member or exit with error
        try:
            member_User = User.objects.get(pk=member_id)
        except ObjectDoesNotExist:
            return ERROR_INVALID_MEMBER

        # calcuate the total words for each interval or exit the function if
        # error
        if (interval == "year" or interval == "month"):
            try:
                total = History.objects.filter(member=member_User).exclude(timestamp__lt=d).aggregate(Sum("words"))
            except:
                return ERROR_INVALID_QUERY

        elif (interval == "week" or interval == "yesterday"):
            try:
                total = History.objects.filter(member=member_User).filter(timestamp__gte=d_start, timestamp__lt=d_end).aggregate(Sum("words"))
            except:
                return ERROR_INVALID_QUERY

        elif (interval == "today"):
            try:
                total = History.objects.filter(member=member_User).exclude(timestamp__lt=d).aggregate(Sum("words"))
            except:
                return ERROR_INVALID_QUERY

        # in the total returns none, set the sum to zero
        if total["words__sum"] == None:
            total["words__sum"] = 0

        return total["words__sum"]




def build_cumulative_dict(userid):

    data = cummulative_total_dict.copy()
    data["thisyear"] = str(get_word_counts("year", userid))
    data["thismonth"] = str(get_word_counts("month", userid))
    data["thisweek"] = str(get_word_counts("week", userid))
    data["yesterday"] = str(get_word_counts("yesterday", userid))
    data["today"] = str(get_word_counts("today", userid))

    return data



# valid day is an int value from 0 - 6 where 0 is Sunday
def build_words_by_weekday_dict(member_id):

    # initialize the data dictionary
    data = weekday_total_dict.copy()

    # get today's datetime
    date_now = datetime.now()
    member_id = int(member_id)

    # get the member or exit with error
    if member_id > 0:
        try:
            member_User = User.objects.get(pk=member_id)
        except ObjectDoesNotExist:
            return ERROR_INVALID_MEMBER

    # all member id's are greater than zero.
    if member_id < 0:
        return ERROR_INVALID_MEMBER

    # get the counts across the site
    for i in range(7):

        # calculate the start and end dates
        d_start = (date_now - timedelta(days=i+1)).date()
        d_end = (d_start + timedelta(days=1))

        # get the total count and store it in the dictionary
        if member_id == 0:
            try:
                total = History.objects.filter(timestamp__gte=d_start, timestamp__lt=d_end).aggregate(Sum("words"))
            except:
                total = {"words__sum":"error"}

        elif member_id > 0:
            try:
                total = History.objects.filter(member=member_User, timestamp__gte=d_start, timestamp__lt=d_end).aggregate(Sum("words"))
            except:
                total = {"words__sum":"error"}

        if total["words__sum"] == None:
            data[d_start.strftime("%A")] = 0
        else:
            data[d_start.strftime("%A")] = total["words__sum"]

    return data








def today_as_str():
    return datetime.date.today().strftime("%Y-%m-%d")


# takes a date string in the format of YYYY-MM-DD
def add_to_this_year(words, this_year, date_string):
    date_array = split(date_string, "-")
    if (date_array[1] == "1" and date_array[2] == "1"):
        return words
    else:
        return words + this_year


def add_to_this_month(words, this_month, date_string):
    date_array = split(date_string, "-")
    if (date_array[2] == 1):
        return words
    else:
        return words + this_month


def add_to_this_week(words, this_week, date_string):
    date_array = split(date_string, "-")
    day_of_week = datetime.datetime(date_array[0], date_array[1], date_array[2]).strftime("%a")
    if (day_of_week.lower() == "mon"):
        return words
    else:
        return words + this_week

# calculated once daily to keep the database up to date
def reset_today(words_dict):
    words_dict["this_year"] = add_to_this_year(words_dict["today"], words_dict["this_year"], today_as_str())
    words_dict["this_month"] = add_to_this_month(words_dict["tquitoday"], words_dict["this_month"], today_as_str())
    words_dict["this_week"] = add_to_this_week(words_dict["today"], words_dict["this_week"], today_as_str())
    words_dict["yesterday"] = words_dict["today"]
    words_dict["today"] = 0
    return words_dict
