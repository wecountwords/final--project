
import json
from datetime import datetime, date

from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.db import IntegrityError
from django.db.models import Avg, Sum
from django.http import JsonResponse
from django.core import serializers
from django.shortcuts import HttpResponse, HttpResponseRedirect, render
from django.urls import reverse
from django.views.decorators.csrf import csrf_exempt
from django.core.exceptions import ObjectDoesNotExist, MultipleObjectsReturned

from words.models import User, Profile, History
from wcconsole.models import URL, Published, Article, Event, NewThisWeek

from . import utils

###  Functions to support views  ###

# Create your views here.
def index(request):

    return render(request, "words/index.html", {
        "testing1": utils.build_cumulative_dict(0),
        "testing2": utils.build_words_by_weekday_dict(0),
        "myuser": request.user.id
        })

@login_required
def profile_view(request):

    if (request.method != "POST"):
        return render(request, "words/profile.html")

    return HttpResponseRedirect(reverse("index"))

def project_view(request, username):

    return render(request, "words/project.html")


def content_view(request):

    return render(request, "words/lists.html", {
        "new_this_week": NewThisWeek.objects.latest('expire_date'),
        "links_list": URL.objects.filter(state="p"),
        "association_list": URL.objects.filter(category="a", state="p"),
        "mags_list": URL.objects.filter(category="m", state="p"),
        "tools_list": URL.objects.filter(category="t", state="p"),
        "events_list": Event.objects.filter(state="p")
    })


### API's

# get the member word written from the word count form and add it to
# the history table
@csrf_exempt
def word_count(request):

    if request.method != "POST":
        return JsonResponse({"error": "error adding word count."}, status=400)

    # get the word count and email
    data = json.loads(request.body)
    member_id = data.get("memberId")
    words_today = data.get("wordsToday")
    member_email = data.get("memberEmail")

    if (member_email == ""):
        try:
            member_User = User.objects.get(pk=member_id)
        except ObjectDoesNotExist:
            return JsonResponse({"error": "unable to find member."}, status=400)
    else:
        try:
            member_User = User.objects.get(email__iexact=member_email)
        except ObjectDoesNotExist:
            return JsonResponse({"error": "unable to find member"}, status=400)
        except MultipleObjectsReturned:
            return JsonResponse({"error": "unable to find member"}, status=400)

    try:
        h = History(member=member_User, words= words_today)
        h.save()
    except:
        return JsonResponse({"error": "unable to save words at this time"})

    return JsonResponse({"success": "words saved."}, status=200)


def update_cumulatives(userObj, words):
    pass



# get the user if they exist, otherwise return error
@csrf_exempt
def totals_by_interval(request, userid):

    member_id = 0

    data = utils.build_cumulative_dict(0)

    # if we find a problem, exit with error
    if data == utils.ERROR_INVALID_PARAMETERS:
        return JsonResponse({"error": "bad parameters."}, status=400)

    if data == utils.ERROR_INVALID_MEMBER:
        return JsonResponse({"error": "bad member."}, status=400)

    if data == utils.ERROR_INVALID_QUERY:
        return JsonResponse({"error": "bad query."}, status=400)

    # otherwise, format the data and send back the respose
    return JsonResponse({"success":data}, status=200)


def totals_by_weekday(request, userid):

    member_id = int(userid)

    data = utils.build_words_by_weekday_dict(userid)

    # if we find a problem, exit with error
    if data == utils.ERROR_INVALID_PARAMETERS:
        return JsonResponse({"error": "bad parameters."}, status=400)

    if data == utils.ERROR_INVALID_MEMBER:
        return JsonResponse({"error": "bad member."}, status=400)

    if data == utils.ERROR_INVALID_QUERY:
        return JsonResponse({"error": "bad query."}, status=400)

    # otherwise, format the data and send back the respose
    return JsonResponse({"success":data}, status=200)


@csrf_exempt
def update_profile(request, userid):

    # get the member
    try:
        user_User = User.objects.get(pk=userid)
    except ObjectDoesNotExist:
        return JsonResponse({"error": "user not found."}, status=400)

    # get the data and try to add it to the model
    if request.method == "POST":
        data = json.loads(request.body)
        words = int(data.get("words"))
        days = int(data.get("days"))

        try:
            p = Profile(member=user_User, daily_goal=words, days_per_week=days)
            p.save()
        except:
            return JsonResponse({"error": "unable to update profile at this time."}, status=400)

        # otherwise the save was successful
        return JsonResponse({"success": "profile updated successfully"}, status=200)

    # if this is an update, try to update the model
    if request.method == "PUT":
        data = json.loads(request.body)
        words = int(data.get("words"))
        days = int(data.get("days"))

        try:
            p = Profile.objects.get(member=user_User)
            p.daily_goal = words
            p.days_per_week = days
            p.save()
        except:
            return JsonResponse({"error": "unable to update profile at this time."}, status=400)

        # otherwise the save was successful
        return JsonResponse({}, status=200)




@csrf_exempt
def update_member(request, userid):

    # get the member
    try:
        user_User = User.objects.get(pk=userid)
    except ObjectDoesNotExist:
        return JsonResponse({"error": "user not found."}, status=400)

    # get the data and try to add it to the model
    if request.method == "POST":
        data = json.loads(request.body)
        first = data.get("first")
        last = data.get("last")
        email = data.get("email")

        try:
            if (len(first) > 0):
                user_User.author_first = first
                user_User.save()

            if (len(last) > 0):
                user_User.author_last = last
                user_User.save()

            if (len(email) > 0):
                user_User.email = email
                user_User.save()

        except:
            return JsonResponse({"error": "unable to update member info at this time."}, status=400)

        # otherwise the save was successful
        return JsonResponse({"success": "member info updated successfully"}, status=200)


###  data functions

def calc_current_count(userid):

    # get the member
    memberObj = get_member_by_id(userid)
    #qset = History.objects.filter(member=memberObj).exclude(timestamp__lt=date.today()).aggregate(sum('words'))
    qset = History.objects.filter(member=memberObj).words
    return qset

### support and helper functions
def get_member_by_name(username):

    try:
        member = User.objects.get(username__iexact='reda')
    except ObjectDoesNotExist:
        return None
    return member

def get_member_by_id(userid):
    try:
        member = User.objects.get(pk=userid)
    except ObjectDoesNotExist:
        return None
    return member





### login, logout, and registration
def login_view(request):
    if request.method == "POST":

        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        # Check if authentication successful
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("index"))
        else:
            return render(request, "words/login.html", {
                "message": "Invalid username and/or password."
            })
    else:
        return render(request, "words/login.html")



def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))



def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]
        # Ensure password matches confirmation
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "words/register.html", {
                "message": "Passwords must match."
            })

        # Ensure the email address is valid

        # Attempt to create new user
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
        except IntegrityError:
            return render(request, "words/register.html", {
                "message": "Username already taken."
            })

        # if registration is successful, login the user and navigate to the
        # user profile page
        login(request, user)
        return HttpResponseRedirect(reverse("profile"))
    else:
        return render(request, "words/register.html")



###  some helper functions  ###
