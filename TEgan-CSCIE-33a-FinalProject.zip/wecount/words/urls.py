from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("project/<str:username>", views.project_view, name="project"),
    path("lists", views.content_view, name = "content"),
    path("profile", views.profile_view, name = "profile"),
    path("login", views.login_view, name="login"),
    path("logout", views.logout_view, name="logout"),
    path("register", views.register, name="register"),

    # API paths
    path("profile/<int:userid>", views.update_profile, name="update_profile" ),
    path("profile/<int:userid>/member", views.update_member, name="update_member"),
    path("wordcount", views.word_count, name="word_count" ),
    path("wordcount/<int:userid>/byweekday", views.totals_by_weekday, name="totals_by_weekday"),
    path("wordcount/<int:userid>/intervals", views.totals_by_interval, name="totals_by_interval"),

]
