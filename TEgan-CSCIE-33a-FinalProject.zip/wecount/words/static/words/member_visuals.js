
document.addEventListener('DOMContentLoaded', function() {


  // get user data
//  data = getCumulativeData(userId);
//getCurrentData(parseInt(document.querySelector('#member_totals').dataset.user))

  // Load the Visualization API and the corechart package.
  google.charts.load('current', {'packages':['corechart']});

  // Set a callback to run when the Google Visualization API is loaded.
  google.charts.setOnLoadCallback(drawChart);

  // Callback that creates and populates a data table,
  // instantiates the pie chart, passes in the data and
  // draws it.

  // draw table to hold cumaltive metrics
  google.charts.load('current', {'packages':['table']});
  google.charts.setOnLoadCallback(drawTable);

});


function drawChart() {

  // Create the data table.
  var data = new google.visualization.DataTable();
  data.addColumn('string', 'Chapter');
  data.addColumn('number', 'Pages');
  data.addRows([
    ['Preface', 3],
    ['Chapter 1', 1],
    ['Chapter 2', 1],
    ['Chapter 3', 1],
    ['Chapter 4', 2]
  ]);

  // Set chart options
  var options = {'title':'How Many Pages I have Written',
                 'width':400,
                 'height':300};

  // Instantiate and draw our chart, passing in some options.
  var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
  chart.draw(data, options);
}


// main table chart with cumulative metrics
// google.charts.load('current', {'packages':['table']});
// google.charts.setOnLoadCallback(drawTable);

var today = '555';
var yesterday = '1010';

function drawTable(data) {
  var data = new google.visualization.DataTable();
  data.addColumn('string', 'Word Count Cummulative Totals');
  data.addColumn('string', 'Total Words');
  data.addColumn('boolean', 'Writing Goal');
  data.addRows([
    ['Today', today, true],
    ['Yesterday', yesterday,  false],
    ['This Week','2843', true],
    ['This Month','2843',  true],
    ['This Year','9004',  true]
  ]);

  var table = new google.visualization.Table(document.getElementById('table_div1'));

  table.draw(data, {showRowNumber: true, width: '100%'});
}


//helper function to retrieve and format data
function getCurrentData(userId) {
  pathAPI = `/stats/${userId}/current`;
  console.log(pathAPI);

  fetch(pathAPI)
  .then(response => {
    if (response.ok) {
      success = true;
      return response.json();
    }
    else {
      return success = false;
    }

  })
  //.then(response => JSON.parse(response))
  .then(results => {
    // print results
    if (success) {
      var mydata = JSON.parse(results);
      console.log(mydata[0].fields.month);
      console.log(JSON.parse(results));
      console.log(results);
    } else {
      console.log(`oops - we have a problem`);
    }
  });
}
