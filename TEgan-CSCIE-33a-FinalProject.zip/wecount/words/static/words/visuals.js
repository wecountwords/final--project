
document.addEventListener('DOMContentLoaded', function() {

  // bar chart
  // Load the Visualization API and the corechart package.
  // Set a callback to run when the Google Visualization API is loaded.

  google.charts.load('current', {'packages':['corechart']});
  google.charts.setOnLoadCallback(drawChart);

  // table
  google.charts.load('current', {'packages':['table']});
  google.charts.setOnLoadCallback(drawTable);

});


// declare some globals then get the data from the server
var Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday;
// get the member id

getWordsByWeekday(0);

// declaring some globals for getting the data to the Total Words table
var today, yesterday, thisweek, thismonth, thisyear;
getWordsCumulative(0);

// drawt the main table cumulative writing stats
function drawTable(data) {
  var data = new google.visualization.DataTable();
  data.addColumn('string', '');
  data.addColumn('string', 'Total Words');
  data.addColumn('boolean', 'Writing Goal');
  data.addRows([
    ['Today', today, true],
    ['Yesterday', yesterday,  true],
    ['This Week', thisweek, true],
    ['This Month', thismonth, true],
    ['This Year', thisyear, true]
  ]);

  var table = new google.visualization.Table(document.getElementById('table_div'));
  table.draw(data, {showRowNumber: true, width: '100%'});
}


// draw bar char with writing stats
function drawChart() {
  var data = google.visualization.arrayToDataTable([
    ['', 'Words', { role: 'style' } ],
    // chart2 add data row
    ['Sunday', Sunday, 'color: #CC3333; opacity: 0.8'],
    ['Monday', Monday, 'color: #CC3333; opacity: 0.8'],
    ['Tuesday', Tuesday, 'color: #CC3333; opacity: 0.8'],
    ['Wednesday', Wednesday, 'color: #CC3333; opacity: 0.8'],
    ['Thursday', Thursday, 'color: #CC3333; opacity: 0.8'],
    ['Friday', Friday, 'color: #CC3333; opacity: 0.8'],
    ['Saturday', Saturday, 'color: #CC3333; opacity: 0.8']
  ]);

    // Set chart options
    var options = {'title':"",
      legend: { position: 'none'},
        //'width':560,
        //'height':300,
      'colors': ['#CC3333'],
      titleTextStyle: { color: "#CC3333"}
    };

    // Instantiate and draw our chart, passing in some options.
    var chart1 = new google.visualization.BarChart(document.getElementById('chart_div1'));
    chart1.draw(data, options);
  }


// ===  functions for adding new and updating user profiles ===

// get the word counts, both sitewide and for the member
// legal interval values inclulde 'year', 'month', 'week', or 'day' case-sensitive
// user id is either a integer id associated with a registered member to
// return the totals for the memeber or 0 to return site-wide totals
var restype;

var isSuccess = false   // global var
function getWordsCumulative(userId) {
  console.log(`entering getWordsCumulative`);
  success = false;
  pathAPI = 'wordcount/0/intervals';
  console.log(pathAPI);

  return // debug return -- need to fix

  fetch(pathAPI)
  .then(response => {
    restype = 'error'
    if (response.ok) {
      restype = 'success'
    }
    return response.json()
  })
  .then (result => {
    setTimeout(2000);
    console.log('writing result:')
    console.log(`restype: ${restype}`)
    console.log( result['success'][0] )
    totals = result["success"][0]
    res = result[restype]
    console.log(totals)
    today = totals.today
    yesterday = totals.yesterday
    thisweek = totals.thisweek
    thismonth = totals.thismonth
    thisyear = totals.thisyear
    console.log(thisyear)
    console.log(thismonth)
  })
}

function getWordTotals(interval, userid) {
  success = false;
  pathAPI = 'wordcount/' + userid + '/' + interval;
  console.log(pathAPI);

  fetch(pathAPI)
  .then(response => {
    restype = 'error'
    if (response.ok) {
      restype = 'success'
    }
    return response.json()
  })
  .then (result => {
    setTimeout(1000);
    console.log('writing result:')
    console.log(`restype: ${restype}`)
    //console.log( result["success"][interval] )
    //t = result["success"][interval]
    res = result[restype]
    t = result[restype][interval]
    console.log(t)
    console.log(`final t = ${t}`);
    return t.toString();
  });
}



function getWordsByWeekday(userid) {
  dayArray = [];
  success = false;
  pathAPI = 'wordcount/' + userid + '/byweekday';
  console.log(pathAPI);

  fetch(pathAPI)
  .then(response => {
    restype = 'error'
    if (response.ok) {
      restype = 'success'
    }
    return response.json()
  })
  .then (result => {
    setTimeout(1000);
    console.log('writing result:')
    console.log(`restype: ${restype}`)
    console.log(result)
    console.log( result["success"]["Tuesday"] )
    console.log( result["success"]["Wednesday"])
    Sunday = result["success"]["Sunday"]
    Monday = result["success"]["Monday"]
    Tuesday = result["success"]["Tuesday"]
    Wednesday = result["success"]["Wednesday"]
    Thursday = result["success"]["Thursday"]
    Friday = result["success"]["Friday"]
    Saturday = result["success"]["Saturday"]
    console.log(Tuesday)
    console.log(Wednesday)

    //res = result[restype]
    //t = result[restype][interval]
    //console.log(t)
    //console.log(`final t = ${t}`)
  });
}
