// words.js manages event-driven front-end activity on the WeCountWords website.

document.addEventListener('DOMContentLoaded', function() {

  // if the form to collect the words written is not visible, then show it.
  document.querySelector('#add-words-link').addEventListener('click', function() {
    clearFields('words')
    showView('words-form')
  });

  // if the member is submitting a word count, get it then clear the fields
  if (document.querySelector('#submit-words')) {
    document.querySelector('#submit-words').addEventListener('click', function() {
      getWordCount(document.querySelector('#words-form').dataset.user),
      document.querySelector('#submit-words').blur(),
      document.querySelector('#add-words').value = ``
    });
  }

  // clicking on the WcCountWords logo navigates to the landing page with
  // cummulative metrics for the region or entire site
  document.querySelector('#home').addEventListener('click', function() {
    document.addEventListener('DOMContentLoaded', function() {
      for (item in document.querySelectorAll('.chart-title')) {
        item.innerHTML = `cumulative`;
      }
    });
  });


  // once logged in, clicking on the stats link navigates to the userids
  // to their personal writing metrics
  if (document.querySelector('#stats-link')) {
    document.querySelector('#stats-link').addEventListener('click', function() {
      clearView('member-view')
      showView('member')
    });
  }


  // add an event listener to the submit to submit or update goals
  if (document.querySelector('#submit-goals')) {
    document.querySelector('#submit-goals').addEventListener('click', function() {
      addProfile(),
      document.querySelector('#submit-goals').blur()
    });
  }


  // add an event listener to update member info
 if (document.querySelector('#submit-member-info')) {
   document.querySelector('#submit-member-info').addEventListener('click', function() {
     addMember()
   });
 }

  // by default on any view that the "add words form" is available, clear it
  // until the user clicks on the link
  if (document.querySelector('#words-form')) {
    clearView('words-form');
  }

});


// add word count
var success;
function getWordCount(userId) {
  console.log(`Entering: getWordCount`);
  var email;

  // get teh word count from the form
  var words = parseInt(document.querySelector('#add-words').value);
  console.log(`${words}`);

  if (userId === "None") {
    email = document.querySelector('#member-email').value;
    userId = 0;
    console.log(`${email}`);
  } else {
    email = '';
    userId = parseInt(userId);
  }

  // send the data to the database
  success = false;
  console.log(`/wordcount`);

  fetch( '/wordcount', {
    method: 'POST',
    body: JSON.stringify({
      memberId: userId,
      memberEmail: email,
      wordsToday: words,
    })
  })
  .then(response => {
    response.json()
    if (response.ok) {
      console.log(response.ok),
      success = true
    }
  })
  .then(result => {
    // print result
    console.log(result);
    if (success) {
      clearFields('words');
    }
  });

}


// get the profile info and save it
function getTargetWords() {

  // get the count in the target field and check its validity
  console.log(`entering checkTargetWords`);
  const targetWords = document.querySelector('[name="target-words"]').value;

  if (targetWords == '') {
    return `Warning: target words per day required.`;

  } else if (parseInt(targetWords) < 100) {
    return `Warning: words per day must be at least 100`;

  } else if (parseInt(targetWords) > 5999) {
    return `Warning: words per day must be less than 6,000`;
  }

  // if there is no error, return the results as str
  return targetWords;
}

function getTargetDays() {

  // get the day count from the target checkboxes and check its validity
  console.log(`entering checkTargetDays`);
  const targetDays = document.querySelectorAll('[name="target-days"]:checked');

  if (targetDays.length === 0) {
    return `Warning: select the number of days you will write`;

  } else if (targetDays.length > 1) {
    return `Warning: too many selections for the number of writing days`;
  }

  // if there is no error, return the results as str
  return targetDays[0].value;
}


function addProfile() {
  // clear any leftover error messages
  console.log(`entering update profile`);
  writeError(``, false, 1);

  // get the goals from the profile view
  words = getTargetWords();
  days = getTargetDays();
  console.log(`words : ${words}  days : ${days}`);

  // if there is a problem with the data, write a warning to the page
  if (words.trim().toLowerCase().startsWith(`warning:`)) {
    writeError(words, true, 1);
    return;
  }

  if (days.trim().toLowerCase().startsWith('warning:')) {
    writeError(days, true, 1);
    return;
  }

  // get the user info for the current user and post it to the backend
  success = false;
  var currentUser = parseInt(document.querySelector('form').dataset.user);
  pathAPI = 'profile/' + currentUser;
  console.log(pathAPI);

  fetch(pathAPI, {
    method: 'POST',
    body: JSON.stringify({
      words: words,
      days: days
    })
  })
  .then(response => {
    if (response.ok) {
      return response.json();
    }
  })
  .then(result => {
    // print result
    console.log(result)
    console.log(result.success);
    if (result.success) {
      writeError(result.success, true, 1);
    }
  });

}

function getName() {
  const first = document.querySelector('[name="firstname"]').value;
  const last = document.querySelector('[name="lastname"]').value;

  console.log(`first : ${first}  last : ${last}`);

  // if the fields are empty, let's get out of this function
  if (first.length === 0 && last.length === 0) {
    return ``;
  }
  console.log(`first.length : ${first.length}  last.length : ${last.length}`);

  // names can be letters and spaces only with length 50 or less
  if (first.length > 50 || last.length > 50 ) {
    // set some limits on the size of the name fields
    return `Warning: names must be fewer than 50 letters and spacess.`;
  }
  // let's be sure we are only letters and spaces
  re = /[^A-Za-z ]+/;
  if (re.test(first) || re.test(last)) {
    console.log(`we are inside the if clause for re`);
    return `Warning: names must be either letters or spaces`;
  }

  console.log(`we are at line 214`);
  //  return a string with first and last
  return `${first}:${last}`;
}

function getEmail() {
  const email = document.querySelector('[name="email"]');

  if (email.value.length === 0) {
    return '';
  }

  if (email.validationMessage.length > 0) {
    return `Warning: ${email.validationMessage}`;
  }

  return email.value;
}

function addMember() {
  // clear any leftover error messages
  console.log(`entering add member info`);
  writeError(``, false, 1);

  var names = getName();
  if (names.trim().toLowerCase().startsWith(`warning:`)) {
    writeError(names, true, 2);
    return;
  }

  var email = getEmail();
  if (email.trim().toLowerCase().startsWith(`warning:`)) {
    writeError(email, true, 2);
    return;
  }

  // if there is no update in any of the fields, exit without submitting data
  // to the backend
  if ( names.split(':')[0].trim().length === 0 &&
      names.split(':')[1].trim().length === 0 &&
      email.trim().length === 0) {
        return;
      }

 console.log(`we are at line 251`);
  var data = {
    first: names.split(':')[0].trim(),
    last: names.split(':')[1].trim(),
    email: email.trim()
  };

  console.log(`${data.first}`);
  console.log(`${data.last}`);
  console.log(`${data.email}`);

  // if we have updated info, send it to the backend
  // get the user info for the current user and post it to the backend
  success = false;
  var currentUser = parseInt(document.querySelector('form').dataset.user);
  pathAPI = 'profile/' + currentUser + '/member';
  console.log(pathAPI);

  fetch(pathAPI, {
    method: 'POST',
    body: JSON.stringify(data)
  })
  .then(response => {
    if (response.ok) {
      return response.json();
    }
  })
  .then(result => {
    // print result
    console.log(result)
    console.log(result.success);
    if (result.success) {
      writeError(result.success, true, 2);
    }
  });
}




// populateForm(formName) retrieves the member info and populates the
// form for viewing or update by the member
function populateForm(formName) {

  if (formName === 'profile') {
    // get the data from the server and put it into the form
    var currentUser = document.querySelector('form').dataset.user;
    pathAPI = 'profile/' + currentUser;
    console.log(pathAPI);
    fetch(pathAPI)
    .then(response => response.json())
    .then(data => console.log(data));
  }
}

// get the profile data from the server
var profileData;

//===  Profile functions  ===//
function getProfile() {
  var currentUser = document.querySelector('form').dataset.user;
  console.log(`${currentUser}`);
  // get the current user and build the request path
  reqPath = 'profile/' + currentUser;
  console.log(reqPath);

  // retrieve the data
  fetch(reqPath)
  .then(response => response.json())
  .then( data => {
    console.log(data),
    profileData = data
  });
}


//===   view functions   ===//
function clearView(page) {
  var p = '#' + page;
  console.log(p);
  document.querySelector(p).style.display = 'none';
}

function showView(page) {
  var p = '#' + page;
  console.log(p);
  document.querySelector(p).style.display = 'block';
}

// input is the name of the form, end state are cleared fields
function clearFields(formName) {
  console.log(`Entering:  clearFields`);

  if (formName.trim().toLowerCase() === 'words') {
    document.querySelector('#add-words').value = ``;
    if (document.querySelector('#member-email')) {
      document.querySelector('#member-email').value = ``;
    }
  }

  if (formName === 'gaols') {
    document.querySelector('.form-control[name="target-words"]').value = ``;
  }

  if (formName === 'member') {
    document.querySelector('.form-control[name="firstname"]').value = ``;
    document.querySelector('.form-control[name="lastname"]').value = ``;
    document.querySelector('.form-control[name="email"]').value=``;
  }
}


// helper functions for checking, unchecking, and disabling checkboxes
// for a collection of checkboxes: boxes
function disableCheckBoxes(boxes, disable) {

  if (boxes.length === 0) {
    return;
  }

  for (let i = 0; i < boxes.length; i++ ) {
    boxes[i].disabled = disable;
  }
}

// helper function to write error to the errorDiv
function writeError(errormsg, isError, formNum) {

  // get a reference to the object
  errorDiv = document.querySelectorAll('.errormsg')[formNum-1];

  // if this is an error, write the message to the innerHTML of the div
  if (errorDiv && isError) {
    errorDiv.innerHTML = errormsg;
  }

  // otherwise, clear the current message
  else if (errorDiv && !isError) {
    errorDiv.innerHTML = ``;
  }
}
