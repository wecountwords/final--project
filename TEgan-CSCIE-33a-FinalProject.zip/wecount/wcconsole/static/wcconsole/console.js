document.addEventListener('DOMContentLoaded', function() {

  // toggle views between the list and new content forms
  document.querySelector('a[data-link="new-article"]').addEventListener('click',
    function(event) {
    event.preventDefault();
    showView('article', true);
    contentId = 0;
  });
  document.querySelector('a[data-link="new-event"]').addEventListener('click',
    function(event) {
    event.preventDefault();
    showView('event', true);
    contentId = 0;
  });
  document.querySelector('a[data-link="new-url"]').addEventListener('click',
    function(event) {
    event.preventDefault();
    showView('url', true);
    contentId = 0;
  });
  document.querySelector('a[data-link="new-this-week"]').addEventListener('click',
    function(event) {
      event.preventDefault();
      showView('ntw', true);
    })

  // open the url, event, article, or archive list. Add an event listern
  // to each of the items in the list
  if (document.querySelector('button[data-type="url"]')) {
    document.querySelector('button[data-type="url"]').addEventListener('click', function() {
      const urls = document.querySelector('#url-list');
      if (urls.style.display === `none`) {
        urls.style.display = `block`;
      } else {
        urls.style.display = `none`;
      }
    })
  }

  if (document.querySelector('button[data-type="event"]')) {
    document.querySelector('button[data-type="event"]').addEventListener('click', function() {
      const events = document.querySelector('#event-list');
      if (events.style.display === `none`) {
        events.style.display = `block`;
      } else {
        events.style.display = `none`;
      }
    })
  }

  if (document.querySelector('button[data-type="blog"]')) {
    document.querySelector('button[data-type="blog"]').addEventListener('click', function() {
      const articles = document.querySelector('#blog-list');
      if (articles.style.display === `none`) {
        articles.style.display = `block`;
      } else {
        articles.style.display = `none`;
      }
    })
  }

  if (document.querySelector('button[data-type="archive"]')) {
    document.querySelector('button[data-type="archive"]').addEventListener('click', function() {
      const archived = document.querySelector('#archive-list');
      if (archived.style.display === `none`) {
        archived.style.display = `block`;
      } else {
        archived.style.display = `none`;
      }
    })
  }

  // put an event listener on each url in the sublist
  if (document.querySelector('#url-list')) {
    const urlLinks = document.querySelectorAll('#url-list .sublist');
    for (let i=0; i<urlLinks.length; i++) {
      urlLinks[i].addEventListener('click', function() {
        contentId = 0;
        openURL(parseInt(urlLinks[i].id.substring(1)))
      })
    }
  }

  // on submit, send url, event, or article to the datastore and return to
  // console landing page
  document.querySelector('[data-submit="article"]').addEventListener('click', submitArticle);
  document.querySelector('[data-submit="event"]').addEventListener('click', submitEvent);
  document.querySelector('[data-submit="url"]').addEventListener('click', submitURL);

  // load the default view
  showView('list');

});


// declaring some constant error values
const REQUIRED_FIELD = '001';
const BAD_REQUEST = '010';
const DATE_ERROR = '020';
const OK = '000';

// declaring some global vars
var contentId;
var success;
var restype;


// ===  functions to open a content itme in their respective form ===
var data = [];
function openURL(urlid) {

  // initialize the contentid for use on submit
  contentId = parseInt(urlid);
  // open the form
  showView('url', true);
  document.querySelector('button[data-submit="url"]').innerHTML = 'Remove';
  document.querySelector('.errormsg').innerHTML = `Removes URL from the member site`

  // retrieve the data and write it to the forms
  pathAPI = 'url/' + urlid;
  console.log(pathAPI);

  fetch(pathAPI)
  .then(response => {
    return response.json()
  })
  .then(result => {
    setTimeout(1000),
    console.log(`writing results:`),
    console.log(JSON.parse(result["success"])),
    data = JSON.parse(result["success"]),
    console.log(data[0]["fields"]["url"]),
    document.querySelector('#link-text').value = data[0]["fields"]["text"],
    document.querySelector('#site-url').value = data[0]["fields"]["url"],
    document.querySelector('#url-category').value = data[0]["fields"]["category"],
    document.querySelector('#link-text').readOnly = true,
    document.querySelector('#site-url').readOnly = true,
    document.querySelector('#url-category').disabled = true
  });

}

// ===  functions to submit data from forms to the datastore ===

// function to save a url
function submitURL() {

  console.log(`entering submitURL`);
  console.log(`contentId = ${contentId}`);

  // get the data from the form
  const urlText = document.querySelector('#link-text').value;
  const urlSite = document.querySelector('#site-url').value;
  const urlCategory = document.querySelector('#url-category').value;

  if (urlCategory === '' || urlSite === '') {
    writeError('url', REQUIRED_FIELD, true);
    return
  }

  console.log(`submitting URL to datastore`);

  // initialize the fetch success var then send the data to the datastore
  success = false;
  fetch('/console/submiturl', {
    method: 'POST',
    body: JSON.stringify({
      urlId: contentId,
      urlText: urlText,
      urlSite: urlSite,
      urlCategory: urlCategory
    })
  })
  .then(response => {
    response.json(),
    success = response.ok
  })
  .then(result => {
    if (!success) {
      return writeError('url', BAD_REQUEST, true);
    }
  });

  // return to the landing page
  showView('list');
  contentId = 0;
}


// functions to retrieve data from the forms and submit it to the database
function submitArticle() {
  console.log(`entering the submitArtile function`)

  const artTitle = document.querySelector('#title').value;
  const artAuthor = document.querySelector('#author').value;
  const artBody = document.querySelector('#body').value;
  const artReady = document.querySelector('#article-ready').checked;

  if (artTitle === '' || artAuthor === '' || artBody === '') {
    writeError('article', REQUIRED_FIELD, true);
    return
  }

  // submit the data to the backend
  console.log(`submitting Article to datastore`);
  success = false;
  fetch('/console/article', {
    method: 'POST',
    body: JSON.stringify({
      artTitle: artTitle,
      artAuthor: artAuthor,
      artBody: artBody,
      artReady: artReady
    })
  })
  .then(response => {
    response.json,
    success = response.ok
  })
  .then(result => {
    if (!success) {
      return writeError('url', BAD_REQUEST, true);
    }
  });

  // return to the landing page
  showView('list');
}



function submitEvent() {
  console.log(`entering the submitEvent function`);

  const eventName = document.querySelector('#event-name').value;
  const eventStart = document.querySelector('#start').value;
  const eventEnd = document.querySelector('#end').value;
  const eventURL = document.querySelector('#event-url').value;
  const eventDetail = document.querySelector('#details').value;

  if (eventName === '' || eventURL === '' || eventDetail === '') {
    writeError('event', REQUIRED_FIELD, true);
    return
  }

  console.log(`submitting Event to datastore`);

  // submit the data to the backend
  success = false;
  fetch('/console/event', {
    method: 'POST',
    body: JSON.stringify({
      eventName: eventName,
      eventStart: eventStart,
      eventEnd: eventEnd,
      eventURL: eventURL,
      eventDetail: eventDetail
    })
  })
  .then(response => {
    response.json,
    success = response.ok
  })
  .then(result => {
    if (!success) {
      return writeError('url', BAD_REQUEST, true);
    }
  });

  // return to the landing page
  showView('list');
}




// ===  functions to Show and Clear views  ===

// shows the view box for content list, add article, or add event
function showView(boxName, addNew) {

  // get the form box name and set it visible.
  if (boxName === 'article') {
    clearView('event');
    clearView('url');
    clearView('list');
    clearView('ntw');
    document.querySelector('#article').style.display = 'block';
    if (addNew) {
      document.querySelector('.btn[data-save="article"]').style.display = 'none';
    }

  } else if (boxName === 'event') {
    clearView('article');
    clearView('url');
    clearView('list');
    clearView('ntw');
    document.querySelector('#event').style.display = 'block';
    if (addNew) {
      document.querySelector('.btn[data-save="event"]').style.display = 'none';
    }

  } else if (boxName === 'url') {
    clearView('article');
    clearView('event');
    clearView('list');
    clearView('ntw');
    document.querySelector('#url').style.display = 'block';
    clearForm('url');
    resetReadOnly('url');

  } else if (boxName === 'ntw') {
    clearView('article');
    clearView('event');
    clearView('url');
    clearView('list');
    document.querySelector('#ntw').style.display = 'block';

  } else if (boxName === 'list') {
    clearView('article');
    clearView('event');
    clearView('url');
    clearView('ntw');
    clearView('sublist');
    document.querySelector('#content-list').style.display = 'block';
  }
}




// functions to clear the view from the web page
function clearView(boxName) {

  // if the form box id is article, then clear the fields and hide the form box
  if (boxName === 'article') {
    clearForm(boxName);
    document.querySelector('#article').style.display = 'none';

  // if the form box id is event, then clear the fields and hide the form box
  } else if (boxName === 'event') {
    clearForm(boxName);
    document.querySelector('#event').style.display = 'none';

    // if the form box id is event, then clear the fields and hide the form box
  } else if (boxName === 'url') {
      clearForm(boxName);
      document.querySelector('button[data-submit="url"]').innerHTML = `Submit`;
      document.querySelector('#url').style.display = 'none';

  // if the form box id is content-list, then hide the list
  } else if (boxName == 'list') {
    document.querySelector('#content-list').style.display = 'none';

   // if the form box id is ntw (new this week), then hide the form box
  } else if (boxName == 'ntw') {
    clearForm(boxName);
    document.querySelector('#ntw').style.display = 'none';

  // if we are on the main console page, reset teh sublists until needed
  } else if (boxName == 'sublist') {
    document.querySelector('#url-list').style.display = `none`;
    document.querySelector('#event-list').style.display = `none`;
    document.querySelector('#blog-list').style.display = `none`;
    document.querySelector('#archive-list').style.display = `none`;
  }
}


// function to clear the form fields
function clearForm(boxName) {

  // if the form box id is article, clear the New Article form fields`
  if (boxName === 'article') {
    document.querySelector('#title').value=``;
    document.querySelector('#author').value=``;
    document.querySelector('#body').value=``;
    document.querySelectorAll('.ready').checked = false;

  // if the form box id is event, clear the New Event form fields
  } else if (boxName === 'event') {
    document.querySelector('#event-name').value=``;
    document.querySelector('#start').value=``;
    document.querySelector('#end').value=``;
    document.querySelector('#event-url').value=``;
    document.querySelector('#details').value=``;
    document.querySelectorAll('.ready').checked = false;

  } else if (boxName === 'url') {
    document.querySelector('#link-text').value = ``;
    document.querySelector('#site-url').value = ``;
    document.querySelector('#url-category').value=``;

  } else if (boxName === 'ntw')  {
    document.querySelector('#ntw-title').value = '';
    document.querySelector('#ntw-details').value = '';
    document.querySelector('#ntw-expiry').value = '';
  }

  // clear error message
  writeError(boxName, OK, false);
}


function resetReadOnly(formName) {

  if (formName == 'url'){
    document.querySelector('#link-text').readOnly = false,
    document.querySelector('#site-url').readOnly = false,
    document.querySelector('#url-category').disabled = false
  }
}

function writeError(boxName, errorCode, writeBool) {

  // initialize an html object var
  const divId = '#' + boxName + '-form > .errormsg';
  const errorDiv = document.querySelector(divId);

  if (writeBool){
    if (errorCode == REQUIRED_FIELD) {
      msg = `Required data missing`;
    } else if (errorCode == BAD_REQUEST) {
      msg = `Unable to submit at this time. Please try later.`
    }
  } else {
    msg =``;
  }

  errorDiv.innerHTML = msg;
}
