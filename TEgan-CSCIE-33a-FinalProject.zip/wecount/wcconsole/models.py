from django.contrib.auth.models import AbstractUser
from django.db import models
from words.models import User
# Create your models here.


# urls are either published (p) or deleted (a). there is no middle save
# state for editing
class URL(models.Model):
    category = models.CharField(max_length=4)
    url = models.URLField(default="http://127.0.0.1:8000")
    text = models.CharField(max_length=120)
    new_item_list = models.BooleanField(default=False)
    state = models.CharField(max_length=1, default="p")


class Published(models.Model):
    last_save_date = models.DateTimeField(auto_now=True)
    ready = models.BooleanField(default=False)
    published = models.BooleanField(default=False)
    doc_num = models.CharField(max_length=8, primary_key=True)


# long form articles are either in a saved state (s), published (p), or
# archived state (a). the only state available to the member site is the
# published state
class Article(models.Model):
    title = models.CharField(max_length=120)
    author = models.CharField(max_length=120)
    body = models.TextField()
    article_num = models.OneToOneField(Published, on_delete=models.CASCADE)
    state = models.CharField(max_length=1, default="s")


# event items are either in a saved state (s), published (p), or
# archived state (a). the only state available to the member site is the
# published state
class Event(models.Model):
    title = models.CharField(max_length=120)
    start = models.DateField()
    end = models.DateField()
    detail = models.TextField()
    url = models.URLField()
    new_item_list = models.BooleanField(default=False)
    event_num = models.OneToOneField(Published, on_delete=models.CASCADE)
    state = models.CharField(max_length=1, default="s")


class NewThisWeek(models.Model):
    title = models.CharField(max_length=120)
    detail = models.TextField()
    expire_date = models.DateField()
