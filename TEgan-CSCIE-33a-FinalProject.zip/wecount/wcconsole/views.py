import json
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.db import IntegrityError
from django.http import JsonResponse
from django.core import serializers
from django.shortcuts import HttpResponse, HttpResponseRedirect, render
from django.urls import reverse
from django.views.decorators.csrf import csrf_exempt
from django.core.exceptions import ObjectDoesNotExist, MultipleObjectsReturned


from wcconsole.models import URL, Article, Event, Published
from words.models import User


def index(request):
    #data = serializers.serialize("json", URL.objects.all())
    return render(request, "wcconsole/index.html", {
        "url_list": URL.objects.values("id", "text", "url", "category", "state"),
        "event_list": Event.objects.values("id", "title", "start", "state"),
        "blog_list": Article.objects.values("id", "title", "state"),
        "data": URL.objects.filter(pk=3)
    })

def faq_view(request):
    return render(request, "wcconsole/faq.html")

###  API's
@csrf_exempt
def submiturl(request):

    # if this is a POST request, add it to our website store otherwise
    # exit with error
    if request.method != "POST":
        return JsonResponse({"error": "bad request."}, status=400)

    data = json.loads(request.body)
    url_id = data.get("urlId")

    # if we have a urlid, since urls are not editable, we will update the
    # the state and be done.
    if (url_id != 0):
        try:
            url = URL.objects.get(pk=url_id)
            url.state = "a"
            url.save()
        except:
            return JsonResponse({"error": "unable to remove"}, status=400)

        return JsonResponse({"success": "url removed successfully"}, status=200)

    # if we are here, this is a new url, so submit it to the models
    url_text = data.get("urlText")
    url_category = data.get("urlCategory")
    url_site = data.get("urlSite")

    try:
        url = URL(category=url_category, url=url_site, text=url_text)
        url.save()
    except:
        return JsonResponse({"error": data}, status=400)

    return JsonResponse({"success": "url added successfully"}, status=200)


@csrf_exempt
def article(request):
    # if this is a POST request, we have a new article. get the field data
    # and add it to the database.
    if request.method != "POST":
        return JsonResponse({"error": "bad request."}, status=400)

    data = json.loads(request.body)
    article_title = data.get("artTitle")
    article_author = data.get("artAuthor")
    article_body = data.get("artBody")
    article_ready = data.get("artReady")

    try:
        article = Article(title=article_title, author=article_author, body=article_body)
        article.save()
    except:
        return JsonResponse({"error": "unable to add article at this time."}, status=400)

    # now update the published table - iteration 3 of final project

    return JsonResponse({"success": "article added"}, status=200)



@csrf_exempt
def event(request):
    # if this is a POST request, we have a new article. get the field data
    # and add it to the database.
    if request.method != "POST":
        return JsonResponse({"error": "bad request."}, status=400)

    data = json.loads(request.body)
    event_name = data.get("eventName")
    event_start = data.get("eventStart")
    event_end = data.get("eventEnd")
    event_detail = data.get("eventDetail")
    event_url = data.get("eventURL")

    # next reserve the doc number in teh Published table
    qset = Published.objects.last().doc_num
    s = str(qset)
    s = str(int(s[1:]) + 1)
    if (len(s) < 4):
        s = s.zfill(4 - len(s))
    num = 'E' + s

    # reserve doc num assuming, based on milestone 1, that we are
    # publishing directly from Add Event.
    try:
        p = Published(doc_num=num)
        p.save()
    except:
        return JsonResponse({"error": "unable to update the Published table."}, status=400)

    # get the db object for the event insert
    try:
        p = None  # reset the reference
        p = Published.objects.last()
    except ObjectDoesNotExist:
        return JsonResponse({"error": "unable to update the Published table."}, status=400)

    try:
        event = Event(title=event_name, start=event_start, end=event_end, detail=event_detail, url=event_url, event_num=p)
        event.save()
    except:
        return JsonResponse({"error": "unable to add event at this time."}, status=400)

    # if we are here, we successfully added an event. now update the published table

    return JsonResponse({"success": "event added"}, status=200)


# if save is true, reserve the document number, otherwise release it and delete
# the entry
@csrf_exempt
def next_number(request, is_save):

    if (is_save):
        p = Published.objects.last().id
        return JsonResponse({"success": "event added"}, status=200)

    return JsonResponse({"error": "unable to get the next number."}, status=400)


# only values valid for type are (1) url (2) event (3) article
@csrf_exempt
def get_url_by_id(request, urlid):

    try:
        data = serializers.serialize("json", URL.objects.filter(pk=urlid))
    except ObjectDoesNotExist:
        return JsonResponse({"error": "bad url id"}, status=400)

    return JsonResponse({"success": data}, status=200)






### Authentication

def logout_view(request):
    pass
