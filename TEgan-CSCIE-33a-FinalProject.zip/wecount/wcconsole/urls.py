from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="console"),
    path("faq", views.faq_view, name="console_faq"),
    path("logout", views.logout_view, name="console_logout"),

    # API paths
    path("article", views.article, name="article"),
    path("event", views.event, name="event"),
    path("submiturl", views.submiturl, name="submiturl"),
    path("url/<int:urlid>", views.get_url_by_id, name="get_url"),
]
