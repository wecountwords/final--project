from django.apps import AppConfig


class WcconsoleConfig(AppConfig):
    name = 'wcconsole'
